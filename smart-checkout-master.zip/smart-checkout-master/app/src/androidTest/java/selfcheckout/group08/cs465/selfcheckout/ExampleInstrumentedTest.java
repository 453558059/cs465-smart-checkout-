package selfcheckout.group08.cs465.selfcheckout;

import android.content.Context;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        /*Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("selfcheckout.group08.cs465.selfcheckout", appContext.getPackageName());*/
    }
}
